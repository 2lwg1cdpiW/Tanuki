package org.koitharu.kotatsu.core.prefs

import androidx.annotation.Keep

@Keep
enum class ListMode {

	LIST, DETAILED_LIST, GRID;
}
