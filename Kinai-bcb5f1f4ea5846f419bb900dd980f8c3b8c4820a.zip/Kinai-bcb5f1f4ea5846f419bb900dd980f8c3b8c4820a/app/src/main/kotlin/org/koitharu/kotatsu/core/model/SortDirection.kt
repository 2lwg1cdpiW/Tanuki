package org.koitharu.kotatsu.core.model

enum class SortDirection {

	ASC, DESC;
}
