package org.koitharu.kotatsu.browser

fun interface OnHistoryChangedListener {

	fun onHistoryChanged()
}
