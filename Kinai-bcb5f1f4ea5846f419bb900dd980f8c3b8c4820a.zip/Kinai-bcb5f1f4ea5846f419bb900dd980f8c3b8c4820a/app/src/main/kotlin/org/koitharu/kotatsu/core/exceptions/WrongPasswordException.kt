package org.koitharu.kotatsu.core.exceptions

class WrongPasswordException : IllegalArgumentException()
