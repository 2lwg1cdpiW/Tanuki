package org.koitharu.kotatsu.core.ui.util

import androidx.recyclerview.widget.RecyclerView

interface RecyclerViewOwner {

	val recyclerView: RecyclerView?
}
