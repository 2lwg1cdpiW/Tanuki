package org.koitharu.kotatsu.core.network

enum class DoHProvider {

	NONE, GOOGLE, CLOUDFLARE, ADGUARD, ZERO_MS
}
